package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class GroupChatActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private ImageButton SendButton;
    private EditText userInput;
    private ScrollView mScrollView;
    private TextView displayText;
    private String currentGroupName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat);

        currentGroupName=getIntent().getExtras().get("group name").toString();
        Toast.makeText( GroupChatActivity.this, currentGroupName, Toast.LENGTH_SHORT).show();
        
        InitializeField();
    }

    private void InitializeField()
    {
        mToolbar=(Toolbar) findViewById(R.id.group_chat_bar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle(currentGroupName);
        SendButton=(ImageButton) findViewById(R.id.send_button);
        userInput=(EditText) findViewById(R.id.input_group);
        displayText=(TextView) findViewById(R.id.group_chat_text);
        mScrollView=(ScrollView)findViewById(R.id.my_scroll_view);

    }
}
